File1 in folder1 content
